"use client"
import { useState } from "react"
import Sidebar from "@/components/sidebar"
import DashboardOverview from "@/components/dashboard-overview"
import "../../styles/dashboard.css"

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  return (
    <div className="dashboard-container">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      <main className={`dashboard-content ${sidebarOpen ? "sidebar-open" : "sidebar-closed"}`}>
        <div className="dashboard-header">
          <h1>Dashboard</h1>
          <div className="user-welcome">Welcome back, User!</div>
        </div>
        <DashboardOverview />
      </main>
    </div>
  )
}

