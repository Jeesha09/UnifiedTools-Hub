/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/qr-generator/route";
exports.ids = ["app/api/qr-generator/route"];
exports.modules = {

/***/ "(rsc)/./app/api/qr-generator/route.ts":
/*!***************************************!*\
  !*** ./app/api/qr-generator/route.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! child_process */ \"child_process\");\n/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! util */ \"util\");\n/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! path */ \"path\");\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! uuid */ \"(rsc)/./node_modules/uuid/dist/esm/v4.js\");\n/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! os */ \"os\");\n/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\n\nconst execAsync = (0,util__WEBPACK_IMPORTED_MODULE_2__.promisify)(child_process__WEBPACK_IMPORTED_MODULE_1__.exec);\nasync function POST(req) {\n    try {\n        const formData = await req.formData();\n        const data = formData.get(\"data\");\n        const color = formData.get(\"color\") || \"black\";\n        const bgColor = formData.get(\"bgColor\") || \"white\";\n        const transparent = formData.get(\"transparent\") === \"true\";\n        const logo = formData.get(\"logo\");\n        const rounded = formData.get(\"rounded\") === \"true\";\n        if (!data) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                error: \"No data provided for QR code\"\n            }, {\n                status: 400\n            });\n        }\n        // Create temp directory for processing\n        const tempDir = path__WEBPACK_IMPORTED_MODULE_4___default().join(os__WEBPACK_IMPORTED_MODULE_5___default().tmpdir(), \"qr-generator-\" + (0,uuid__WEBPACK_IMPORTED_MODULE_6__[\"default\"])());\n        fs__WEBPACK_IMPORTED_MODULE_3___default().mkdirSync(tempDir, {\n            recursive: true\n        });\n        // Output path\n        const outputPath = path__WEBPACK_IMPORTED_MODULE_4___default().join(tempDir, \"qrcode.png\");\n        // Handle logo if provided\n        let logoPath = \"\";\n        if (logo) {\n            logoPath = path__WEBPACK_IMPORTED_MODULE_4___default().join(tempDir, \"logo.png\");\n            const logoBuffer = Buffer.from(await logo.arrayBuffer());\n            fs__WEBPACK_IMPORTED_MODULE_3___default().writeFileSync(logoPath, logoBuffer);\n        }\n        // Create Python script parameters\n        const params = [\n            `\"${data}\"`,\n            `\"${outputPath}\"`,\n            logoPath ? `\"${logoPath}\"` : \"None\",\n            `\"${color}\"`,\n            transparent ? \"None\" : `\"${bgColor}\"`,\n            transparent ? \"True\" : \"False\",\n            rounded ? \"True\" : \"False\"\n        ];\n        // Execute Python script\n        const pythonCommand = `python -c \"\nimport sys\nsys.path.append('python')\nfrom qrGenerator import generate_qr\ngenerate_qr(${params.join(\", \")})\n\"`;\n        await execAsync(pythonCommand);\n        // Read the output file\n        const outputBuffer = fs__WEBPACK_IMPORTED_MODULE_3___default().readFileSync(outputPath);\n        // Clean up temp files\n        fs__WEBPACK_IMPORTED_MODULE_3___default().rmSync(tempDir, {\n            recursive: true,\n            force: true\n        });\n        return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(outputBuffer, {\n            headers: {\n                \"Content-Type\": \"image/png\",\n                \"Content-Disposition\": 'attachment; filename=\"qrcode.png\"'\n            }\n        });\n    } catch (error) {\n        console.error(\"QR generation error:\", error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            error: \"Failed to generate QR code\"\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL3FyLWdlbmVyYXRvci9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTREO0FBQ3hCO0FBQ0o7QUFDYjtBQUNJO0FBQ1k7QUFDaEI7QUFFbkIsTUFBTVEsWUFBWU4sK0NBQVNBLENBQUNELCtDQUFJQTtBQUV6QixlQUFlUSxLQUFLQyxHQUFnQjtJQUN6QyxJQUFJO1FBQ0YsTUFBTUMsV0FBVyxNQUFNRCxJQUFJQyxRQUFRO1FBQ25DLE1BQU1DLE9BQU9ELFNBQVNFLEdBQUcsQ0FBQztRQUMxQixNQUFNQyxRQUFRLFNBQVVELEdBQUcsQ0FBQyxZQUF1QjtRQUNuRCxNQUFNRSxVQUFVLFNBQVVGLEdBQUcsQ0FBQyxjQUF5QjtRQUN2RCxNQUFNRyxjQUFjTCxTQUFTRSxHQUFHLENBQUMsbUJBQW1CO1FBQ3BELE1BQU1JLE9BQU9OLFNBQVNFLEdBQUcsQ0FBQztRQUMxQixNQUFNSyxVQUFVUCxTQUFTRSxHQUFHLENBQUMsZUFBZTtRQUU1QyxJQUFJLENBQUNELE1BQU07WUFDVCxPQUFPWixxREFBWUEsQ0FBQ21CLElBQUksQ0FBQztnQkFBRUMsT0FBTztZQUErQixHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDcEY7UUFFQSx1Q0FBdUM7UUFDdkMsTUFBTUMsVUFBVWxCLGdEQUFTLENBQUNHLGdEQUFTLElBQUksa0JBQWtCRCxnREFBTUE7UUFDL0RILG1EQUFZLENBQUNtQixTQUFTO1lBQUVJLFdBQVc7UUFBSztRQUV4QyxjQUFjO1FBQ2QsTUFBTUMsYUFBYXZCLGdEQUFTLENBQUNrQixTQUFTO1FBRXRDLDBCQUEwQjtRQUMxQixJQUFJTSxXQUFXO1FBQ2YsSUFBSVgsTUFBTTtZQUNSVyxXQUFXeEIsZ0RBQVMsQ0FBQ2tCLFNBQVM7WUFDOUIsTUFBTU8sYUFBYUMsT0FBT0MsSUFBSSxDQUFDLE1BQU1kLEtBQUtlLFdBQVc7WUFDckQ3Qix1REFBZ0IsQ0FBQ3lCLFVBQVVDO1FBQzdCO1FBRUEsa0NBQWtDO1FBQ2xDLE1BQU1LLFNBQVM7WUFDYixDQUFDLENBQUMsRUFBRXRCLEtBQUssQ0FBQyxDQUFDO1lBQ1gsQ0FBQyxDQUFDLEVBQUVlLFdBQVcsQ0FBQyxDQUFDO1lBQ2pCQyxXQUFXLENBQUMsQ0FBQyxFQUFFQSxTQUFTLENBQUMsQ0FBQyxHQUFHO1lBQzdCLENBQUMsQ0FBQyxFQUFFZCxNQUFNLENBQUMsQ0FBQztZQUNaRSxjQUFjLFNBQVMsQ0FBQyxDQUFDLEVBQUVELFFBQVEsQ0FBQyxDQUFDO1lBQ3JDQyxjQUFjLFNBQVM7WUFDdkJFLFVBQVUsU0FBUztTQUNwQjtRQUVELHdCQUF3QjtRQUN4QixNQUFNaUIsZ0JBQWdCLENBQUM7Ozs7WUFJZixFQUFFRCxPQUFPWCxJQUFJLENBQUMsTUFBTTtDQUMvQixDQUFDO1FBRUUsTUFBTWYsVUFBVTJCO1FBRWhCLHVCQUF1QjtRQUN2QixNQUFNQyxlQUFlakMsc0RBQWUsQ0FBQ3dCO1FBRXJDLHNCQUFzQjtRQUN0QnhCLGdEQUFTLENBQUNtQixTQUFTO1lBQUVJLFdBQVc7WUFBTWEsT0FBTztRQUFLO1FBRWxELE9BQU8sSUFBSXZDLHFEQUFZQSxDQUFDb0MsY0FBYztZQUNwQ0ksU0FBUztnQkFDUCxnQkFBZ0I7Z0JBQ2hCLHVCQUF1QjtZQUN6QjtRQUNGO0lBQ0YsRUFBRSxPQUFPcEIsT0FBTztRQUNkcUIsUUFBUXJCLEtBQUssQ0FBQyx3QkFBd0JBO1FBQ3RDLE9BQU9wQixxREFBWUEsQ0FBQ21CLElBQUksQ0FBQztZQUFFQyxPQUFPO1FBQTZCLEdBQUc7WUFBRUMsUUFBUTtRQUFJO0lBQ2xGO0FBQ0YiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcSkVFU0hBXFxGYXZvcml0ZXNcXERvd25sb2Fkc1xcY3NcXGFwcFxcYXBpXFxxci1nZW5lcmF0b3JcXHJvdXRlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHR5cGUgTmV4dFJlcXVlc3QsIE5leHRSZXNwb25zZSB9IGZyb20gXCJuZXh0L3NlcnZlclwiXG5pbXBvcnQgeyBleGVjIH0gZnJvbSBcImNoaWxkX3Byb2Nlc3NcIlxuaW1wb3J0IHsgcHJvbWlzaWZ5IH0gZnJvbSBcInV0aWxcIlxuaW1wb3J0IGZzIGZyb20gXCJmc1wiXG5pbXBvcnQgcGF0aCBmcm9tIFwicGF0aFwiXG5pbXBvcnQgeyB2NCBhcyB1dWlkdjQgfSBmcm9tIFwidXVpZFwiXG5pbXBvcnQgb3MgZnJvbSBcIm9zXCJcblxuY29uc3QgZXhlY0FzeW5jID0gcHJvbWlzaWZ5KGV4ZWMpXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcTogTmV4dFJlcXVlc3QpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBmb3JtRGF0YSA9IGF3YWl0IHJlcS5mb3JtRGF0YSgpXG4gICAgY29uc3QgZGF0YSA9IGZvcm1EYXRhLmdldChcImRhdGFcIikgYXMgc3RyaW5nXG4gICAgY29uc3QgY29sb3IgPSAoZm9ybURhdGEuZ2V0KFwiY29sb3JcIikgYXMgc3RyaW5nKSB8fCBcImJsYWNrXCJcbiAgICBjb25zdCBiZ0NvbG9yID0gKGZvcm1EYXRhLmdldChcImJnQ29sb3JcIikgYXMgc3RyaW5nKSB8fCBcIndoaXRlXCJcbiAgICBjb25zdCB0cmFuc3BhcmVudCA9IGZvcm1EYXRhLmdldChcInRyYW5zcGFyZW50XCIpID09PSBcInRydWVcIlxuICAgIGNvbnN0IGxvZ28gPSBmb3JtRGF0YS5nZXQoXCJsb2dvXCIpIGFzIEZpbGVcbiAgICBjb25zdCByb3VuZGVkID0gZm9ybURhdGEuZ2V0KFwicm91bmRlZFwiKSA9PT0gXCJ0cnVlXCJcblxuICAgIGlmICghZGF0YSkge1xuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgZXJyb3I6IFwiTm8gZGF0YSBwcm92aWRlZCBmb3IgUVIgY29kZVwiIH0sIHsgc3RhdHVzOiA0MDAgfSlcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgdGVtcCBkaXJlY3RvcnkgZm9yIHByb2Nlc3NpbmdcbiAgICBjb25zdCB0ZW1wRGlyID0gcGF0aC5qb2luKG9zLnRtcGRpcigpLCBcInFyLWdlbmVyYXRvci1cIiArIHV1aWR2NCgpKVxuICAgIGZzLm1rZGlyU3luYyh0ZW1wRGlyLCB7IHJlY3Vyc2l2ZTogdHJ1ZSB9KVxuXG4gICAgLy8gT3V0cHV0IHBhdGhcbiAgICBjb25zdCBvdXRwdXRQYXRoID0gcGF0aC5qb2luKHRlbXBEaXIsIFwicXJjb2RlLnBuZ1wiKVxuXG4gICAgLy8gSGFuZGxlIGxvZ28gaWYgcHJvdmlkZWRcbiAgICBsZXQgbG9nb1BhdGggPSBcIlwiXG4gICAgaWYgKGxvZ28pIHtcbiAgICAgIGxvZ29QYXRoID0gcGF0aC5qb2luKHRlbXBEaXIsIFwibG9nby5wbmdcIilcbiAgICAgIGNvbnN0IGxvZ29CdWZmZXIgPSBCdWZmZXIuZnJvbShhd2FpdCBsb2dvLmFycmF5QnVmZmVyKCkpXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGxvZ29QYXRoLCBsb2dvQnVmZmVyKVxuICAgIH1cblxuICAgIC8vIENyZWF0ZSBQeXRob24gc2NyaXB0IHBhcmFtZXRlcnNcbiAgICBjb25zdCBwYXJhbXMgPSBbXG4gICAgICBgXCIke2RhdGF9XCJgLFxuICAgICAgYFwiJHtvdXRwdXRQYXRofVwiYCxcbiAgICAgIGxvZ29QYXRoID8gYFwiJHtsb2dvUGF0aH1cImAgOiBcIk5vbmVcIixcbiAgICAgIGBcIiR7Y29sb3J9XCJgLFxuICAgICAgdHJhbnNwYXJlbnQgPyBcIk5vbmVcIiA6IGBcIiR7YmdDb2xvcn1cImAsXG4gICAgICB0cmFuc3BhcmVudCA/IFwiVHJ1ZVwiIDogXCJGYWxzZVwiLFxuICAgICAgcm91bmRlZCA/IFwiVHJ1ZVwiIDogXCJGYWxzZVwiLFxuICAgIF1cblxuICAgIC8vIEV4ZWN1dGUgUHl0aG9uIHNjcmlwdFxuICAgIGNvbnN0IHB5dGhvbkNvbW1hbmQgPSBgcHl0aG9uIC1jIFwiXG5pbXBvcnQgc3lzXG5zeXMucGF0aC5hcHBlbmQoJ3B5dGhvbicpXG5mcm9tIHFyR2VuZXJhdG9yIGltcG9ydCBnZW5lcmF0ZV9xclxuZ2VuZXJhdGVfcXIoJHtwYXJhbXMuam9pbihcIiwgXCIpfSlcblwiYFxuXG4gICAgYXdhaXQgZXhlY0FzeW5jKHB5dGhvbkNvbW1hbmQpXG5cbiAgICAvLyBSZWFkIHRoZSBvdXRwdXQgZmlsZVxuICAgIGNvbnN0IG91dHB1dEJ1ZmZlciA9IGZzLnJlYWRGaWxlU3luYyhvdXRwdXRQYXRoKVxuXG4gICAgLy8gQ2xlYW4gdXAgdGVtcCBmaWxlc1xuICAgIGZzLnJtU3luYyh0ZW1wRGlyLCB7IHJlY3Vyc2l2ZTogdHJ1ZSwgZm9yY2U6IHRydWUgfSlcblxuICAgIHJldHVybiBuZXcgTmV4dFJlc3BvbnNlKG91dHB1dEJ1ZmZlciwge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImltYWdlL3BuZ1wiLFxuICAgICAgICBcIkNvbnRlbnQtRGlzcG9zaXRpb25cIjogJ2F0dGFjaG1lbnQ7IGZpbGVuYW1lPVwicXJjb2RlLnBuZ1wiJyxcbiAgICAgIH0sXG4gICAgfSlcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiUVIgZ2VuZXJhdGlvbiBlcnJvcjpcIiwgZXJyb3IpXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgZXJyb3I6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIFFSIGNvZGVcIiB9LCB7IHN0YXR1czogNTAwIH0pXG4gIH1cbn1cblxuIl0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsImV4ZWMiLCJwcm9taXNpZnkiLCJmcyIsInBhdGgiLCJ2NCIsInV1aWR2NCIsIm9zIiwiZXhlY0FzeW5jIiwiUE9TVCIsInJlcSIsImZvcm1EYXRhIiwiZGF0YSIsImdldCIsImNvbG9yIiwiYmdDb2xvciIsInRyYW5zcGFyZW50IiwibG9nbyIsInJvdW5kZWQiLCJqc29uIiwiZXJyb3IiLCJzdGF0dXMiLCJ0ZW1wRGlyIiwiam9pbiIsInRtcGRpciIsIm1rZGlyU3luYyIsInJlY3Vyc2l2ZSIsIm91dHB1dFBhdGgiLCJsb2dvUGF0aCIsImxvZ29CdWZmZXIiLCJCdWZmZXIiLCJmcm9tIiwiYXJyYXlCdWZmZXIiLCJ3cml0ZUZpbGVTeW5jIiwicGFyYW1zIiwicHl0aG9uQ29tbWFuZCIsIm91dHB1dEJ1ZmZlciIsInJlYWRGaWxlU3luYyIsInJtU3luYyIsImZvcmNlIiwiaGVhZGVycyIsImNvbnNvbGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/qr-generator/route.ts\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fqr-generator%2Froute&page=%2Fapi%2Fqr-generator%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fqr-generator%2Froute.ts&appDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fqr-generator%2Froute&page=%2Fapi%2Fqr-generator%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fqr-generator%2Froute.ts&appDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_JEESHA_Favorites_Downloads_cs_app_api_qr_generator_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/qr-generator/route.ts */ \"(rsc)/./app/api/qr-generator/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/qr-generator/route\",\n        pathname: \"/api/qr-generator\",\n        filename: \"route\",\n        bundlePath: \"app/api/qr-generator/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\JEESHA\\\\Favorites\\\\Downloads\\\\cs\\\\app\\\\api\\\\qr-generator\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_JEESHA_Favorites_Downloads_cs_app_api_qr_generator_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZxci1nZW5lcmF0b3IlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRnFyLWdlbmVyYXRvciUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRnFyLWdlbmVyYXRvciUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNKRUVTSEElNUNGYXZvcml0ZXMlNUNEb3dubG9hZHMlNUNjcyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDSkVFU0hBJTVDRmF2b3JpdGVzJTVDRG93bmxvYWRzJTVDY3MmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQzZCO0FBQzFHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxKRUVTSEFcXFxcRmF2b3JpdGVzXFxcXERvd25sb2Fkc1xcXFxjc1xcXFxhcHBcXFxcYXBpXFxcXHFyLWdlbmVyYXRvclxcXFxyb3V0ZS50c1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvcXItZ2VuZXJhdG9yL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvcXItZ2VuZXJhdG9yXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9xci1nZW5lcmF0b3Ivcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxKRUVTSEFcXFxcRmF2b3JpdGVzXFxcXERvd25sb2Fkc1xcXFxjc1xcXFxhcHBcXFxcYXBpXFxcXHFyLWdlbmVyYXRvclxcXFxyb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcyB9ID0gcm91dGVNb2R1bGU7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHdvcmtBc3luY1N0b3JhZ2UsXG4gICAgICAgIHdvcmtVbml0QXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBwYXRjaEZldGNoLCAgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXBwLXJvdXRlLmpzLm1hcCJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fqr-generator%2Froute&page=%2Fapi%2Fqr-generator%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fqr-generator%2Froute.ts&appDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/uuid"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fqr-generator%2Froute&page=%2Fapi%2Fqr-generator%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fqr-generator%2Froute.ts&appDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CJEESHA%5CFavorites%5CDownloads%5Ccs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();